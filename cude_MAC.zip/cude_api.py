"""
FastAPI application exposing Cude functionality.

This module defines a FastAPI application with a handful of routes that
mirror the command‑line interfaces provided by the underlying Cude
package.  Each route accepts JSON payloads describing the desired
operation and delegates execution to the corresponding functions in
``cude``.  For long‑running tasks (e.g. summarising large folders)
the routes run synchronously and return once the task has completed.

Note that this API is intentionally lightweight; it performs only
minimal validation and does not attempt to shield callers from the
computational cost of running the underlying algorithms.  It is
intended primarily as a demonstration of how to wrap the existing
scripts in a web service.  For production use you should add
asynchronous task management, authentication, error handling and
resource limits as appropriate.
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import subprocess
from pathlib import Path
from typing import Optional, List

from cude import (
    summary as summary_module,
    compare_sum as compare_module,
    rearrange_deep as rearrange_deep_module,
    derearrange_deep as derearrange_deep_module,
    download_all_models as download_module,
)


app = FastAPI(title="Cude API", description="Expose Cude CLI functions via HTTP", version="0.2.0")


class SummaryRequest(BaseModel):
    folder: str
    model: Optional[str] = "llama/model.gguf"
    vision_model: Optional[str] = "llama3.2-vision"
    chunk_tokens: Optional[int] = 1800
    ctx: Optional[int] = 4096
    no_cude: Optional[bool] = False


@app.post("/summary")
def api_summary(req: SummaryRequest):
    """Run the Cude summarisation over a folder.

    The underlying function writes its output to the ``memory`` folder
    relative to the current working directory.  This endpoint does not
    return that data inline; instead it reports completion status and
    the path to the generated JSON lines file.  To retrieve the
    summaries you will need to read the file from disk.
    """
    folder = Path(req.folder).expanduser().resolve()
    if not folder.exists() or not folder.is_dir():
        raise HTTPException(status_code=400, detail="Folder does not exist")
    try:
        # Call the main function directly rather than spawning a new
        # process.  This is equivalent to running ``python summary.py``.
        summary_module.main(
            [
                str(folder),
                "--model", req.model,
                "--vision-model", req.vision_model,
                "--chunk-tokens", str(req.chunk_tokens),
                "--ctx", str(req.ctx),
            ]
            + (["--no-cude"] if req.no_cude else []),
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    out_file = Path("memory/llm_file_summaries.jsonl").resolve()
    return {"status": "ok", "output": str(out_file)}


class CompareRequest(BaseModel):
    sentence: str
    root: str
    summary_file: Optional[str] = None
    embed_model: Optional[str] = "sentence-transformers/all-MiniLM-L6-v2"
    llm_model: Optional[str] = "llama/model.gguf"
    no_llm_folder_name: Optional[bool] = False
    out_dir: Optional[str] = "rearranged_by_summary"
    mode: Optional[str] = "copy"
    report_only: Optional[bool] = False


@app.post("/compare")
def api_compare(req: CompareRequest):
    """Compare a sentence against existing summaries and rearrange by similarity."""
    root = Path(req.root).expanduser().resolve()
    if not root.exists() or not root.is_dir():
        raise HTTPException(status_code=400, detail="Root folder does not exist")
    summary_file = req.summary_file or str(Path("memory/llm_file_summaries.jsonl").resolve())
    try:
        args = [
            req.sentence,
            "--root", str(root),
            "--summary", summary_file,
            "--embed-model", req.embed_model,
            "--llm-model", req.llm_model,
            "--out-dir", req.out_dir,
            "--mode", req.mode,
            "--out-json", str(Path("memory/compare_summary_layers.json").resolve()),
            "--out-txt", str(Path("memory/compare_summary_layers.txt").resolve()),
        ]
        if req.no_llm_folder_name:
            args.append("--no-llm-folder-name")
        if req.report_only:
            args.append("--report-only")
        compare_module.main(args)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    return {"status": "ok", "output_dir": req.out_dir}


class RearrangeRequest(BaseModel):
    paths: Optional[List[str]] = None
    old: Optional[str] = None
    taxonomy: Optional[str] = "clean_taxonomy.txt"
    model: Optional[str] = "sentence-transformers/all-MiniLM-L6-v2"
    archive_months: Optional[int] = 6
    no_archive: Optional[bool] = False
    archive_remove_original: Optional[bool] = False
    allow_folder_move: Optional[bool] = False
    dry_run: Optional[bool] = False
    random_state: Optional[int] = 42


@app.post("/rearrange_deep")
def api_rearrange(req: RearrangeRequest):
    """Run the deep rearranger over selected paths or an old root."""
    # Validate inputs
    if not req.paths and not req.old:
        raise HTTPException(status_code=400, detail="Provide either paths or an old root")
    args = []
    if req.paths:
        # Write paths to a temporary file because the CLI expects a file
        tmp_file = Path("selected_paths.txt").resolve()
        tmp_file.write_text("\n".join(req.paths), encoding="utf-8")
        args += ["--paths", str(tmp_file)]
    if req.old:
        root = Path(req.old).expanduser().resolve()
        if not root.exists():
            raise HTTPException(status_code=400, detail="old root does not exist")
        args += ["--old", str(root)]
    args += [
        "--taxonomy", req.taxonomy,
        "--model", req.model,
        "--archive-months", str(req.archive_months),
        "--random-state", str(req.random_state),
    ]
    if req.no_archive:
        args.append("--no-archive")
    if req.archive_remove_original:
        args.append("--archive-remove-original")
    if req.allow_folder_move:
        args.append("--allow-folder-move")
    if req.dry_run:
        args.append("--dry-run")
    try:
        rearrange_deep_module.main(args)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    return {"status": "ok"}


class DerearrangeRequest(BaseModel):
    manifest: str
    dry_run: Optional[bool] = False
    remove_empty_folders: Optional[bool] = False


@app.post("/derearrange_deep")
def api_derearrange(req: DerearrangeRequest):
    """Undo a deep rearrangement using its manifest."""
    manifest = Path(req.manifest).expanduser().resolve()
    if not manifest.exists():
        raise HTTPException(status_code=400, detail="Manifest file does not exist")
    args = [
        "--manifest", str(manifest),
    ]
    if req.dry_run:
        args.append("--dry-run")
    if req.remove_empty_folders:
        args.append("--remove-empty-folders")
    try:
        derearrange_deep_module.main(args)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    return {"status": "ok"}


class DownloadRequest(BaseModel):
    llama: Optional[str] = "cuda"
    skip_florence: Optional[bool] = False
    skip_qwen: Optional[bool] = False


@app.post("/download_models")
def api_download(req: DownloadRequest):
    """Download all models (llama.cpp binaries, Qwen GGUFs, Florence model)."""
    try:
        download_module.main([
            "--llama", req.llama,
        ] + (["--skip-florence"] if req.skip_florence else []) + (["--skip-qwen"] if req.skip_qwen else []))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    return {"status": "ok"}