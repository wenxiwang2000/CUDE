Cude Rearranger - macOS version
===============================

This is the macOS build package for your Cude rearrangement app.
Everything previously named BigBoss has been renamed to Cude/cude.

Main workflow
-------------
1. Select one big folder.
2. Click Run.
3. Cude first runs name-based embedding rearrangement.
4. It creates an undo manifest: _rearrange_deep_manifest.json.
5. After the first rearrangement, it asks whether to run deep mode.
6. Deep mode uses your local llama GGUF plus summary/vision pipeline.
7. It then creates deeper semantic folders based on your query.
8. Click Undo to restore the name-based rearrangement using the manifest.

How to run directly on Mac
--------------------------
First unzip cude.zip. Then open Terminal in the unzipped folder and run:

    chmod +x run_cude_mac.command build_mac_app.command
    ./run_cude_mac.command

You can also double-click run_cude_mac.command after giving permission.
The first run will create a local .venv and install dependencies.

How to build a real macOS .app
------------------------------
Open Terminal in the unzipped folder and run:

    chmod +x build_mac_app.command
    ./build_mac_app.command

After the build finishes, your app will be here:

    dist/Cude_Rearranger.app

You can then double-click the .app.

Important llama/model placement
-------------------------------
For deep mode, put your llama folder at the same level as the command scripts:

    cude_mac_app/
      llama/
        llama-cli
        model.gguf
      run_cude_mac.command
      build_mac_app.command
      run_gui.py
      cude/

If your llama executable is named main instead of llama-cli, the code will also try to find it.

Core GUI buttons
----------------
- Select folder
- Remove selected
- Clear
- Run
- Undo

PyPI / pip install option
-------------------------
From the unzipped folder:

    python3 -m pip install .

Then you can run:

    cude-gui
    cude-rearrange-deep --old /path/to/folder
    cude-derearrange-deep --manifest /path/to/folder/_rearrange_deep_manifest.json

Note
----
This zip is a macOS build project, not a pre-built signed .app, because a true macOS app bundle must be built on macOS. Run build_mac_app.command on your Mac to generate the .app.
