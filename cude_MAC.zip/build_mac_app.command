#!/bin/bash
set -e
cd "$(dirname "$0")"

if [ ! -d ".venv" ]; then
  echo "Creating local Python environment..."
  python3 -m venv .venv
fi

source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements_mac.txt
python -m pip install pyinstaller

export PYTHONPATH="$PWD:$PYTHONPATH"
pyinstaller --noconfirm --windowed --name "Cude_Rearranger" \
  --add-data "clean_taxonomy.txt:." \
  --collect-all sentence_transformers \
  --collect-all sklearn \
  --collect-all transformers \
  run_gui.py

echo ""
echo "Done. Your macOS app is here: dist/Cude_Rearranger.app"
echo "Place your llama/ folder with model.gguf beside the .app or in this project folder for deep mode."
