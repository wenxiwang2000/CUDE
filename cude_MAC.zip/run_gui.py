"""Launch the Cude GUI."""

from cude_gui import main

if __name__ == "__main__":
    main()
