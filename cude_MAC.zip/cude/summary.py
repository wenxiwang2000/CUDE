"""
Summarise text, PDF and image files in a folder using local models.

This module is a refactoring of the original ``summary.py`` script.  It
exposes a ``main`` function that accepts an optional ``argv`` list.  If
``argv`` is ``None`` the command‑line arguments are read from
``sys.argv``.  The summariser uses a local llama.cpp model to
summarise text and PDF files, and optionally a vision model (via
Ollama) to caption images.  Summaries are written to a ``memory``
directory in JSONL and per‑chunk text files.
"""

import argparse
import base64
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Tuple, List


TEXT_EXTS = {".txt", ".md", ".py", ".r", ".csv", ".json", ".yaml", ".yml", ".html", ".css", ".js", ".ts", ".java", ".cpp", ".c", ".log"}
PDF_EXTS = {".pdf"}
IMG_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}
ALL_EXTS = TEXT_EXTS | PDF_EXTS | IMG_EXTS


def clean(x: str) -> str:
    x = x.replace("\x00", " ")
    x = re.sub(r"[ \t]+", " ", x)
    x = re.sub(r"\n{3,}", "\n\n", x)
    return x.strip()


def token_n(x: str) -> int:
    return max(1, len(x) // 4)


def target_words(x: str, ratio: float = 0.10) -> int:
    return max(12, int(len(re.findall(r"\S+", x)) * ratio))


def safe_name(x: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_.-]+", "__", x)[:180]


def run_cude(folder: Path, chunk_size: int = 500) -> None:
    """Run the external Cude detector/embedding builder if available."""
    exe = shutil.which("cude")
    if not exe:
        print("[Cude] CLI not found. Install with: pip install Cude")
        return
    print("[Cude] running detector/pre-builder...")
    cmd = [exe, "--folder", str(folder), "--chunk-size", str(chunk_size), "--embed"]
    try:
        subprocess.run(cmd, check=False)
    except Exception as e:
        print(f"[Cude] skipped because: {e}")


def read_plain(p: Path) -> str:
    for enc in ["utf-8", "utf-8-sig", "cp1252", "latin-1"]:
        try:
            return p.read_text(encoding=enc, errors="ignore")
        except Exception:
            pass
    return ""


def read_pdf(p: Path) -> str:
    try:
        import fitz  # type: ignore
        doc = fitz.open(str(p))
        text = "\n".join(f"\n[page {i+1}]\n" + (page.get_text("text") or "") for i, page in enumerate(doc))
        doc.close()
        return text
    except Exception:
        return ""


def ocr_image(p: Path) -> str:
    try:
        from PIL import Image  # type: ignore
        import pytesseract  # type: ignore
        return pytesseract.image_to_string(Image.open(p))
    except Exception:
        return ""


def ollama_vision_summary(p: Path, model: str) -> str:
    """Call the local Ollama vision model via its command‑line API."""
    if not shutil.which("ollama"):
        return ""
    try:
        img64 = base64.b64encode(p.read_bytes()).decode("utf-8")
        payload = {
            "model": model,
            "prompt": (
                "Give one short useful summary of this image for a file-memory system. "
                "If it is a screenshot, mention the software, error, code, table, chart, or visible text. "
                "If it is a normal photo, mention the main objects, scene, and purpose. "
                "Return one sentence only."
            ),
            "images": [img64],
            "stream": False,
        }
        r = subprocess.run(
            ["ollama", "api", "generate"],
            input=json.dumps(payload),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="ignore",
            timeout=180,
        )
        if r.returncode != 0:
            return ""
        data = json.loads(r.stdout)
        return clean(data.get("response", ""))
    except Exception:
        return ""


def image_summary_text(p: Path, vision_model: str) -> str:
    vision = ollama_vision_summary(p, vision_model) if vision_model else ""
    ocr = clean(ocr_image(p))
    if vision and ocr:
        return clean(f"Vision summary: {vision}\nOCR text from image: {ocr}")
    if vision:
        return clean(f"Vision summary: {vision}")
    if ocr:
        return clean(f"OCR text from image: {ocr}")
    return ""


def extract_text_or_image_summary(p: Path, vision_model: str) -> Tuple[str, str]:
    e = p.suffix.lower()
    if e in TEXT_EXTS:
        return clean(read_plain(p)), "text"
    if e in PDF_EXTS:
        return clean(read_pdf(p)), "pdf"
    if e in IMG_EXTS:
        return image_summary_text(p, vision_model), "image"
    return "", "unknown"


def split_chunks(text: str, max_tokens: int) -> List[str]:
    text = clean(text)
    if not text:
        return []
    parts = re.split(r"\n\s*\n", text)
    buf = ""
    out: List[str] = []
    for part in parts:
        part = part.strip()
        if not part:
            continue
        cand = (buf + "\n\n" + part).strip() if buf else part
        if token_n(cand) <= max_tokens:
            buf = cand
        else:
            if buf:
                out.append(buf)
            if token_n(part) > max_tokens:
                size = max_tokens * 4
                out += [part[i : i + size].strip() for i in range(0, len(part), size) if part[i : i + size].strip()]
                buf = ""
            else:
                buf = part
    if buf:
        out.append(buf)
    return out


def llama_cli() -> Path:
    for p in [Path("llama/llama-cli.exe"), Path("llama/main.exe"), Path("llama/llama-cli"), Path("llama/main")]:
        if p.exists():
            return p
    raise FileNotFoundError("Put llama-cli.exe or llama-cli inside ./llama/")


def ask_text_llm(prompt: str, model: Path, ctx: int, new_tokens: int) -> str:
    cmd = [str(llama_cli()), "-m", str(model), "-c", str(ctx), "-n", str(new_tokens), "--temp", "0.1", "-p", prompt]
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="ignore")
    if r.returncode != 0:
        raise RuntimeError(r.stderr.strip())
    out = clean(r.stdout)
    return clean(out.replace(prompt, "", 1)) if out.startswith(prompt) else out


def chunk_prompt(fname: str, file_type: str, i: int, n: int, txt: str) -> str:
    return f"""You are a concise Cude file-memory summarizer.
Summarize this {file_type} chunk into LESS THAN 10% of its original length.
Target maximum: about {target_words(txt)} words.
Keep names, numbers, methods, commands, paths, results, visible objects, visible text, and conclusions.
Remove repetition. Do not invent. Return only one compact paragraph.

File: {fname}
Chunk: {i}/{n}

Text:
{txt}

Summary:"""


def file_prompt(fname: str, file_type: str, sums: List[str]) -> str:
    ordered = "\n".join(f"{i+1}. {s}" for i, s in enumerate(sums))
    return f"""You are a concise Cude file-memory summarizer.
These are ordered summaries from one {file_type} file.
Answer: what is this file?
Return exactly one sentence in this format:
{fname} -- <one sentence summary>

Ordered chunk summaries:
{ordered}

Final summary:"""


def detected_files(root: Path):
    for p in root.rglob("*"):
        if p.is_file() and p.suffix.lower() in ALL_EXTS and "memory" not in p.parts:
            yield p


def summarize_file(p: Path, root: Path, model: Path, out: Path, chunk_tokens: int, ctx: int, vision_model: str) -> dict:
    rel = str(p.relative_to(root))
    text, file_type = extract_text_or_image_summary(p, vision_model)
    if not text:
        return {"file": rel, "type": file_type, "status": "skipped_no_text_or_image_summary", "summary": ""}
    chunks = split_chunks(text, chunk_tokens)
    cdir = out / "llm_chunk_summaries" / safe_name(rel)
    cdir.mkdir(parents=True, exist_ok=True)
    sums: List[str] = []
    for i, ch in enumerate(chunks, 1):
        s = ask_text_llm(chunk_prompt(rel, file_type, i, len(chunks), ch), model, ctx, min(256, max(48, target_words(ch) * 2)))
        sums.append(s)
        (cdir / f"chunk_{i:04d}.txt").write_text(s, encoding="utf-8")
    final = ask_text_llm(file_prompt(rel, file_type, sums), model, ctx, 96)
    return {"file": rel, "type": file_type, "status": "ok", "chunks": len(chunks), "summary": final, "embedding_text": final}


def main(argv: List[str] | None = None) -> None:
    """Entry point for the summary command."""
    ap = argparse.ArgumentParser(description="Cude + local text LLM + local vision model summary builder")
    ap.add_argument("folder")
    ap.add_argument("--model", default="llama/model.gguf", help="text GGUF model path, e.g. qwen3 0.6B/1.7B")
    ap.add_argument("--vision-model", default="llama3.2-vision", help="Ollama vision model for png/jpg/webp; use empty string to disable")
    ap.add_argument("--chunk-tokens", type=int, default=1800)
    ap.add_argument("--ctx", type=int, default=4096)
    ap.add_argument("--no-cude", action="store_true")
    args = ap.parse_args(argv)

    root = Path(args.folder).expanduser().resolve()
    model = Path(args.model).expanduser().resolve()
    out = Path("memory").resolve()
    out.mkdir(exist_ok=True)

    if not args.no_cude:
        run_cude(root)

    items = list(detected_files(root))
    save = out / "llm_file_summaries.jsonl"
    print(f"[summary.py] detected files: {len(items)}")
    print(f"[text model] {model}")
    print(f"[vision model] {args.vision_model or 'disabled'}")
    print(f"[output] {save}")
    with save.open("w", encoding="utf-8") as f:
        for k, p in enumerate(items, 1):
            print(f"\n[{k}/{len(items)}] {p.relative_to(root)}")
            try:
                r = summarize_file(p, root, model, out, args.chunk_tokens, args.ctx, args.vision_model)
            except Exception as e:
                r = {"file": str(p.relative_to(root)), "status": "error", "error": str(e), "summary": ""}
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
            f.flush()
            print(r.get("status"), r.get("summary", ""))
    print(f"\n[DONE] saved: {save}")


if __name__ == "__main__":  # pragma: no cover
    main()