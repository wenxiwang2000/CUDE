# Text/JSON Patch README

I will give you a text-like file such as `.txt`, `.md`, `.json`, `.yaml`, `.csv`, `.html`, `.css`, or `.js`, plus a change request.

Return only one file:
- `patch.json`

Goal:
Patch the existing file with minimal edits.
Do not regenerate the whole file.

Use this schema:
{
  "file_type": "text",
  "target_file": "example.txt",
  "operations": [
    {"action": "replace_text", "old": "A", "new": "B", "count": 1},
    {"action": "insert_after", "match": "hello", "text": "\\nnew line"},
    {"action": "insert_before", "match": "hello", "text": "new line\\n"},
    {"action": "delete_text", "old": "remove me", "count": 1}
  ]
}

Rules:
- output only `patch.json`
- do not return the full rebuilt file
- use exact matches
- keep edits small and deterministic
- fail clearly if a required target is missing

Output:
Return only valid `patch.json`
Nothing else.
