# Word Patch README

I will give you an existing `.docx` file and a change request.

Return only one file:
- `patch.json`

Goal:
Patch the existing Word file with minimal edits.
Do not rewrite the whole document.

Use this schema:
{
  "file_type": "docx",
  "target_file": "file.docx",
  "operations": [
    {"action": "replace_text", "old": "A", "new": "B", "count": 1},
    {"action": "replace_paragraph", "paragraph_index": 2, "text": "New paragraph"},
    {"action": "insert_paragraph_after", "paragraph_index": 2, "text": "Added paragraph"},
    {"action": "replace_table_cell", "table_index": 0, "row": 1, "col": 2, "text": "Cell text"},
    {"action": "update_header", "section": 0, "text": "Header text"},
    {"action": "update_footer", "section": 0, "text": "Footer text"}
  ]
}

Rules:
- output only `patch.json`
- do not return the full rebuilt document
- use exact targets
- keep edits small and deterministic
- fail clearly if a required target is missing

Output:
Return only valid `patch.json`
Nothing else.
