import argparse
import json
from pathlib import Path

import fitz


def main() -> int:
    p = argparse.ArgumentParser(description="Apply patch.json to a PDF file")
    p.add_argument("patch", nargs="?", default="patch.json")
    p.add_argument("--inplace", action="store_true")
    args = p.parse_args()

    patch = json.loads(Path(args.patch).read_text(encoding="utf-8"))
    target = Path(patch["target_file"])
    doc = fitz.open(str(target))

    for i, op in enumerate(patch.get("operations", []), start=1):
        action = op["action"]
        if action == "update_metadata":
            meta = doc.metadata or {}
            meta.update(op["metadata"])
            doc.set_metadata(meta)
            continue

        page = doc[op["page"] - 1]

        if action == "replace_text":
            hits = page.search_for(op["old"])
            if not hits:
                raise ValueError(f"replace_text target not found on page {op['page']}: {op['old']!r}")
            count = op.get("count")
            if count not in (None, 0):
                hits = hits[:count]
            for rect in hits:
                page.add_redact_annot(rect, fill=(1, 1, 1))
            page.apply_redactions()
            for rect in hits:
                page.insert_text((rect.x0, rect.y1 - 2), op["new"], fontsize=op.get("fontsize", 11))
        elif action == "insert_text":
            page.insert_text((op["x"], op["y"]), op["text"], fontsize=op.get("fontsize", 11))
        elif action == "redact_region":
            rect = fitz.Rect(*op["rect"])
            page.add_redact_annot(rect, fill=(1, 1, 1))
            page.apply_redactions()
        elif action == "overlay_block":
            rect = fitz.Rect(*op["rect"])
            page.insert_textbox(rect, op["text"], fontsize=op.get("fontsize", 11), overlay=True)
        else:
            raise ValueError(f"unsupported action #{i}: {action}")

    out = target if args.inplace else target.with_name(f"{target.stem}.patched{target.suffix}")
    doc.save(str(out))
    doc.close()
    print(f"OK: wrote {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
