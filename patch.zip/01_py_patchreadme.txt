# Python Patch README

I will give you the raw `code.py` and a change request.

Return only one file:
- `patch.py`

Goal:
Patch the existing `code.py` with minimal edits.
Do not regenerate the whole file.

Rules:
- output only `patch.py`
- `patch.py` must read `code.py`
- use exact replace / insert / delete operations
- fail clearly if expected old text is not found
- write the patched result back to disk
- print clear success or error messages
- do not output a rebuilt full `code.py`

Preferred patch style inside `patch.py`:
- read file
- define small patch operations
- apply them one by one
- write file back

Output:
Return only the complete content of `patch.py`
Nothing else.
