import argparse
import json
from pathlib import Path

from docx import Document
from docx.oxml import OxmlElement
from docx.text.paragraph import Paragraph


def insert_paragraph_after(paragraph, text: str):
    new_p = OxmlElement("w:p")
    paragraph._p.addnext(new_p)
    new_para = Paragraph(new_p, paragraph._parent)
    new_para.text = text
    return new_para


def replace_limited(text: str, old: str, new: str, remaining: int | None) -> tuple[str, int]:
    if old not in text:
        return text, 0
    if remaining is None:
        return text.replace(old, new), text.count(old)
    used = min(text.count(old), remaining)
    return text.replace(old, new, used), used


def main() -> int:
    p = argparse.ArgumentParser(description="Apply patch.json to a DOCX file")
    p.add_argument("patch", nargs="?", default="patch.json")
    p.add_argument("--inplace", action="store_true")
    args = p.parse_args()

    patch = json.loads(Path(args.patch).read_text(encoding="utf-8"))
    target = Path(patch["target_file"])
    doc = Document(str(target))

    for i, op in enumerate(patch.get("operations", []), start=1):
        action = op["action"]
        if action == "replace_text":
            old, new = op["old"], op.get("new", "")
            remaining = None if op.get("count") in (None, 0) else int(op["count"])
            changed = 0

            paragraph_groups = [doc.paragraphs]
            for section in doc.sections:
                paragraph_groups.append(section.header.paragraphs)
                paragraph_groups.append(section.footer.paragraphs)

            for group in paragraph_groups:
                for para in group:
                    if remaining == 0:
                        break
                    updated, used = replace_limited(para.text, old, new, remaining)
                    if used:
                        para.text = updated
                        changed += used
                        if remaining is not None:
                            remaining -= used
                if remaining == 0:
                    break

            if remaining != 0:
                for table in doc.tables:
                    for row in table.rows:
                        for cell in row.cells:
                            if remaining == 0:
                                break
                            updated, used = replace_limited(cell.text, old, new, remaining)
                            if used:
                                cell.text = updated
                                changed += used
                                if remaining is not None:
                                    remaining -= used
                        if remaining == 0:
                            break
                    if remaining == 0:
                        break

            if changed == 0:
                raise ValueError(f"replace_text target not found: {old!r}")
        elif action == "replace_paragraph":
            doc.paragraphs[op["paragraph_index"]].text = op["text"]
        elif action == "insert_paragraph_after":
            insert_paragraph_after(doc.paragraphs[op["paragraph_index"]], op["text"])
        elif action == "replace_table_cell":
            doc.tables[op["table_index"]].cell(op["row"], op["col"]).text = op["text"]
        elif action == "update_header":
            sec = doc.sections[op.get("section", 0)]
            if sec.header.paragraphs:
                sec.header.paragraphs[0].text = op["text"]
            else:
                sec.header.add_paragraph(op["text"])
        elif action == "update_footer":
            sec = doc.sections[op.get("section", 0)]
            if sec.footer.paragraphs:
                sec.footer.paragraphs[0].text = op["text"]
            else:
                sec.footer.add_paragraph(op["text"])
        else:
            raise ValueError(f"unsupported action #{i}: {action}")

    out = target if args.inplace else target.with_name(f"{target.stem}.patched{target.suffix}")
    doc.save(str(out))
    print(f"OK: wrote {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
