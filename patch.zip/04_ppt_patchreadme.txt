# PowerPoint Patch README

I will give you an existing `.pptx` file and a change request.

Return only one file:
- `patch.json`

Goal:
Patch the existing PowerPoint with minimal edits.
Do not rebuild the whole deck.

Use this schema:
{
  "file_type": "pptx",
  "target_file": "slides.pptx",
  "operations": [
    {"action": "replace_text", "slide": 1, "match": "Old Title", "new": "New Title", "count": 1},
    {"action": "replace_shape_text", "slide": 1, "shape_name": "Title 1", "text": "Exact new text"},
    {"action": "replace_table_cell", "slide": 1, "shape_name": "Table 1", "row": 1, "col": 2, "text": "Cell text"},
    {"action": "add_textbox", "slide": 1, "text": "New box", "left": 1.0, "top": 1.0, "width": 3.0, "height": 1.0},
    {"action": "delete_shape", "slide": 1, "shape_name": "Old Box"}
  ]
}

Rules:
- output only `patch.json`
- do not return the full rebuilt deck
- use exact slide and shape targets
- keep edits small and deterministic
- fail clearly if a required target is missing

Output:
Return only valid `patch.json`
Nothing else.
