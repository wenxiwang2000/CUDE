import argparse
import json
from pathlib import Path

from pptx import Presentation
from pptx.util import Inches


def find_shape(slide, shape_name: str):
    for shape in slide.shapes:
        if getattr(shape, "name", None) == shape_name:
            return shape
    raise ValueError(f"shape not found: {shape_name!r}")


def delete_shape(shape) -> None:
    el = shape._element
    el.getparent().remove(el)


def main() -> int:
    p = argparse.ArgumentParser(description="Apply patch.json to a PPTX file")
    p.add_argument("patch", nargs="?", default="patch.json")
    p.add_argument("--inplace", action="store_true")
    args = p.parse_args()

    patch = json.loads(Path(args.patch).read_text(encoding="utf-8"))
    target = Path(patch["target_file"])
    prs = Presentation(str(target))

    for i, op in enumerate(patch.get("operations", []), start=1):
        slide = prs.slides[op["slide"] - 1]
        action = op["action"]
        if action == "replace_text":
            hits = 0
            for shape in slide.shapes:
                if getattr(shape, "has_text_frame", False) and op["match"] in shape.text:
                    shape.text = shape.text.replace(op["match"], op["new"], op.get("count", 0) or -1)
                    hits += 1
            if hits == 0:
                raise ValueError(f"replace_text target not found on slide {op['slide']}: {op['match']!r}")
        elif action == "replace_shape_text":
            find_shape(slide, op["shape_name"]).text = op["text"]
        elif action == "replace_table_cell":
            shape = find_shape(slide, op["shape_name"])
            shape.table.cell(op["row"], op["col"]).text = op["text"]
        elif action == "add_textbox":
            slide.shapes.add_textbox(Inches(op["left"]), Inches(op["top"]), Inches(op["width"]), Inches(op["height"])).text = op["text"]
        elif action == "delete_shape":
            delete_shape(find_shape(slide, op["shape_name"]))
        else:
            raise ValueError(f"unsupported action #{i}: {action}")

    out = target if args.inplace else target.with_name(f"{target.stem}.patched{target.suffix}")
    prs.save(str(out))
    print(f"OK: wrote {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
