import argparse
import subprocess
import sys
from pathlib import Path


def main() -> int:
    p = argparse.ArgumentParser(description="Run a GPT-generated patch.py")
    p.add_argument("patch", nargs="?", default="patch.py", help="path to generated patch.py")
    p.add_argument("--python", default=sys.executable, help="python executable to use")
    args = p.parse_args()

    patch = Path(args.patch)
    if not patch.exists():
        print(f"ERROR: patch file not found: {patch}")
        return 1

    result = subprocess.run([args.python, str(patch)], check=False)
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
