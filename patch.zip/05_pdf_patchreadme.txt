# PDF Patch README

I will give you an existing `.pdf` file and a change request.

Return only one file:
- `patch.json`

Goal:
Patch the existing PDF with minimal edits.
Do not rebuild the full PDF unless absolutely necessary.

Use this schema:
{
  "file_type": "pdf",
  "target_file": "paper.pdf",
  "operations": [
    {"action": "replace_text", "page": 1, "old": "A", "new": "B", "count": 1, "fontsize": 11},
    {"action": "insert_text", "page": 1, "x": 72, "y": 72, "text": "Hello", "fontsize": 11},
    {"action": "redact_region", "page": 1, "rect": [72, 72, 180, 95]},
    {"action": "overlay_block", "page": 1, "rect": [72, 72, 240, 130], "text": "Block text", "fontsize": 11},
    {"action": "update_metadata", "metadata": {"title": "New Title"}}
  ]
}

Rules:
- output only `patch.json`
- do not return the full rebuilt PDF
- use exact page/text/region targets
- keep edits small and deterministic
- fail clearly if a required target is missing

Output:
Return only valid `patch.json`
Nothing else.
