import argparse
import json
from pathlib import Path


def replace_text(text: str, old: str, new: str, count: int | None) -> str:
    if old not in text:
        raise ValueError(f"replace_text target not found: {old!r}")
    return text.replace(old, new, -1 if count in (None, 0) else count)


def insert_after(text: str, match: str, add: str) -> str:
    idx = text.find(match)
    if idx < 0:
        raise ValueError(f"insert_after target not found: {match!r}")
    idx += len(match)
    return text[:idx] + add + text[idx:]


def insert_before(text: str, match: str, add: str) -> str:
    idx = text.find(match)
    if idx < 0:
        raise ValueError(f"insert_before target not found: {match!r}")
    return text[:idx] + add + text[idx:]


def main() -> int:
    p = argparse.ArgumentParser(description="Apply patch.json to a text-like file")
    p.add_argument("patch", nargs="?", default="patch.json")
    p.add_argument("--inplace", action="store_true", help="overwrite target file")
    args = p.parse_args()

    patch_path = Path(args.patch)
    patch = json.loads(patch_path.read_text(encoding="utf-8"))
    target = Path(patch["target_file"])
    text = target.read_text(encoding="utf-8")

    for i, op in enumerate(patch.get("operations", []), start=1):
        action = op["action"]
        if action == "replace_text":
            text = replace_text(text, op["old"], op.get("new", ""), op.get("count"))
        elif action == "insert_after":
            text = insert_after(text, op["match"], op["text"])
        elif action == "insert_before":
            text = insert_before(text, op["match"], op["text"])
        elif action == "delete_text":
            text = replace_text(text, op["old"], "", op.get("count"))
        else:
            raise ValueError(f"unsupported action #{i}: {action}")

    out = target if args.inplace else target.with_name(f"{target.stem}.patched{target.suffix}")
    out.write_text(text, encoding="utf-8")
    print(f"OK: wrote {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
