# rearrange_deep.py
# Deep path-based rearranger with priorities + JSON undo manifest.
#
# Input can be:
#   --paths selected_paths.txt
#   or --old "C:\path\to\one_root"
#
# Logic:
# - It accepts files/folders from the UI path list.
# - It deduplicates paths and ignores repeated names in the same parent layer.
# - It never mixes layers: each folder layer is clustered separately.
# - It processes deepest folders first, then outside folders.
# - It can move files and folders only within their current parent layer into cluster folders.
# - It protects code/system files from move/archive/delete.
# - It creates priority cluster folders like:
#      P01_01_media__photo
#      P02_02_documents__pdf
# - Priority is based on cluster size first, then taxonomy score.
# - It writes _rearrange_deep_manifest.json for undo.
#
# Install:
#   pip install sentence-transformers scikit-learn numpy
#
# Run preview:
#   python rearrange_deep.py --paths selected_paths.txt --dry-run
#
# Run:
#   python rearrange_deep.py --paths selected_paths.txt
#
# Restore:
#   python derearrange_deep.py --manifest "C:\root\_rearrange_deep_manifest.json"

import argparse
import json
import shutil
import zipfile
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import normalize


PROTECTED_EXTS = {
    ".py", ".pyw", ".ipynb",
    ".bat", ".cmd", ".ps1", ".sh", ".bash", ".zsh",
    ".js", ".jsx", ".ts", ".tsx",
    ".html", ".htm", ".css", ".scss",
    ".json", ".yaml", ".yml", ".xml", ".toml", ".ini", ".cfg", ".conf",
    ".sql", ".r", ".rmd",
    ".java", ".c", ".cpp", ".h", ".hpp", ".cs", ".go", ".rs", ".swift", ".kt",
    ".php", ".rb", ".pl", ".lua",
    ".exe", ".dll", ".sys", ".msi", ".app", ".dmg",
    ".lnk", ".url",
}

SYSTEM_FILES = {
    "_rearrange_deep_manifest.json",
    "_rearrange_deep_report.txt",
}


def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def safe_name(name: str) -> str:
    bad = '<>:"/\\|?*'
    for ch in bad:
        name = name.replace(ch, "_")
    return name.replace("/", "__").strip() or "cluster"


def unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    parent, stem, suffix = path.parent, path.stem, path.suffix
    i = 2
    while True:
        p = parent / f"{stem}_{i}{suffix}"
        if not p.exists():
            return p
        i += 1


def rel(path: Path, root: Path) -> str:
    return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")


def abs_from_root(root: Path, s: str) -> Path:
    return root / s.replace("/", "\\")


def is_generated_cluster_folder(p: Path) -> bool:
    n = p.name
    return p.is_dir() and len(n) >= 7 and n[0] == "P" and n[1:3].isdigit() and n[3] == "_" and n[4:6].isdigit() and n[6] == "_"


def is_archive_zip(p: Path) -> bool:
    return p.is_file() and p.name.startswith("_archive_not_modified_") and p.suffix.lower() == ".zip"


def is_system_output(p: Path) -> bool:
    return p.name in SYSTEM_FILES or is_archive_zip(p)


def is_protected_file(p: Path) -> bool:
    return p.is_file() and p.suffix.lower() in PROTECTED_EXTS


def safe_to_touch(p: Path, allow_folders: bool) -> bool:
    if is_system_output(p):
        return False
    if is_generated_cluster_folder(p):
        return False
    if p.is_file():
        return not is_protected_file(p)
    if p.is_dir():
        return allow_folders
    return False


def item_text(p: Path, max_children=60) -> str:
    def clean(s):
        return s.replace("_", " ").replace("-", " ")

    if p.is_file():
        return clean(p.stem)

    names = [clean(p.name)]
    try:
        for i, c in enumerate(p.iterdir()):
            if i >= max_children:
                break
            names.append(clean(c.stem if c.is_file() else c.name))
    except PermissionError:
        pass
    return " ".join(names)


def load_taxonomy(path: Path) -> list[str]:
    labels, seen = [], set()
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "/" not in line:
            continue
        if line not in seen:
            seen.add(line)
            labels.append(line)
    if not labels:
        raise ValueError("clean_taxonomy.txt has no valid parent/child labels.")
    return labels


def read_input_paths(paths_file: str | None, old: str | None) -> list[Path]:
    paths = []
    if old:
        paths.append(Path(old))
    if paths_file:
        f = Path(paths_file).expanduser().resolve()
        if not f.exists():
            raise FileNotFoundError(f"Paths file not found: {f}")
        for line in f.read_text(encoding="utf-8").splitlines():
            line = line.strip().strip('"')
            if line:
                paths.append(Path(line))
    out, seen = [], set()
    for p in paths:
        try:
            rp = p.expanduser().resolve()
        except OSError:
            continue
        if rp.exists() and str(rp).lower() not in seen:
            seen.add(str(rp).lower())
            out.append(rp)
    return out


def roots_from_paths(paths: list[Path]) -> list[Path]:
    """
    If path is folder, that folder is a root.
    If path is file, its parent becomes a root.
    Remove child roots when parent root already included.
    """
    candidates = []
    for p in paths:
        candidates.append(p if p.is_dir() else p.parent)

    candidates = sorted(set(candidates), key=lambda x: len(x.parts))
    roots = []
    for c in candidates:
        if not any(c == r or r in c.parents for r in roots):
            roots.append(c)
    return roots


def selected_items_by_parent(paths: list[Path], root: Path, allow_folders: bool) -> dict[Path, list[Path]]:
    """
    Path-list mode:
    - If user selected files, only those files are candidates.
    - If user selected folders, all direct safe children at every layer under that folder are candidates.
    """
    selected = defaultdict(list)

    selected_files = [p for p in paths if p.is_file() and (p == root or root in p.parents)]
    selected_folders = [p for p in paths if p.is_dir() and (p == root or root in p.parents)]

    for f in selected_files:
        if safe_to_touch(f, allow_folders):
            selected[f.parent].append(f)

    for folder in selected_folders:
        # include all folders under selected folder, deepest organization later
        for parent in [p for p in folder.rglob("*") if p.is_dir()] + [folder]:
            try:
                for child in parent.iterdir():
                    if safe_to_touch(child, allow_folders):
                        selected[parent].append(child)
            except PermissionError:
                pass

    # remove duplicate names in same parent layer
    cleaned = {}
    for parent, items in selected.items():
        seen_names = set()
        keep = []
        for item in items:
            key = item.name.lower()
            if key in seen_names:
                continue
            seen_names.add(key)
            if item.exists() and item.parent == parent:
                keep.append(item)
        if keep:
            cleaned[parent] = keep

    return cleaned


def k_range_by_size(n: int):
    if n < 3:
        return []
    hi = 6 if n < 50 else 12 if n <= 300 else 20
    return list(range(2, min(hi, n - 1) + 1))


def choose_best_k(vectors: np.ndarray, random_state: int):
    ks = k_range_by_size(len(vectors))
    if not ks:
        return 1, {}
    best_k, best_score, scores = ks[0], -999.0, {}
    for k in ks:
        km = KMeans(n_clusters=k, random_state=random_state, n_init="auto")
        labels = km.fit_predict(vectors)
        if len(set(labels)) < 2 or len(set(labels)) >= len(vectors):
            continue
        score = silhouette_score(vectors, labels, metric="cosine")
        scores[k] = float(score)
        if score > best_score:
            best_k, best_score = k, score
    return best_k, scores


def nearest_taxonomy_labels(centers, taxonomy_labels, taxonomy_vectors):
    centers = normalize(centers)
    taxonomy_vectors = normalize(taxonomy_vectors)
    out, used = [], set()
    for c in centers:
        sims = taxonomy_vectors @ c
        order = np.argsort(-sims)
        chosen = int(order[0])
        for idx in order:
            label = taxonomy_labels[int(idx)]
            if label not in used:
                chosen = int(idx)
                break
        label = taxonomy_labels[chosen]
        used.add(label)
        out.append((label, float(sims[chosen])))
    return out


def newest_modified_time(path: Path) -> float:
    newest = path.stat().st_mtime
    if path.is_dir():
        try:
            for c in path.rglob("*"):
                try:
                    newest = max(newest, c.stat().st_mtime)
                except (FileNotFoundError, PermissionError):
                    pass
        except PermissionError:
            pass
    return newest


def archive_old_items(parent: Path, root: Path, items: list[Path], months: int, remove_original: bool, dry_run: bool, manifest: dict):
    cutoff_ts = (datetime.now() - timedelta(days=months * 30)).timestamp()
    old_items, keep = [], []
    for item in items:
        try:
            mt = newest_modified_time(item)
        except (FileNotFoundError, PermissionError):
            keep.append(item)
            continue
        if mt < cutoff_ts:
            old_items.append(item)
        else:
            keep.append(item)

    if not old_items:
        return keep

    zip_path = unique_path(parent / f"_archive_not_modified_{months}_months.zip")
    print(f"[ARCHIVE] {parent} | {len(old_items)} old item(s) -> {zip_path.name}")

    rec = {
        "type": "archive_zip",
        "time": now_str(),
        "parent": rel(parent, root),
        "zip_path": rel(zip_path, root),
        "months": months,
        "remove_original": bool(remove_original),
        "items": [],
    }

    for item in old_items:
        rec["items"].append({
            "original_path": rel(item, root),
            "arcname": rel(item, root),
            "is_dir": item.is_dir(),
            "last_modified": datetime.fromtimestamp(newest_modified_time(item)).strftime("%Y-%m-%d %H:%M"),
        })

    if dry_run:
        return keep

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zipf:
        for item in old_items:
            if item.is_file():
                zipf.write(item, rel(item, root))
            elif item.is_dir():
                # Folder may contain code; archive only safe non-code files inside.
                for f in item.rglob("*"):
                    if f.is_file() and not is_protected_file(f):
                        zipf.write(f, rel(f, root))

    if remove_original:
        for item in old_items:
            if item.is_file():
                item.unlink()
            elif item.is_dir():
                # only remove safe non-code files, not code
                for f in item.rglob("*"):
                    if f.is_file() and not is_protected_file(f):
                        try:
                            f.unlink()
                        except OSError:
                            pass

    manifest["operations"].append(rec)
    return keep


def priority_order(cluster_infos):
    """
    cluster_infos fields:
    id, label, taxonomy_score, items
    priority: bigger cluster first, then better taxonomy score
    """
    return sorted(cluster_infos, key=lambda x: (-len(x["items"]), -x["taxonomy_score"], x["id"]))


def cluster_and_move(parent: Path, root: Path, items: list[Path], model, taxonomy_labels, taxonomy_vectors,
                     random_state: int, dry_run: bool, manifest: dict):
    if not items:
        return

    queries = [item_text(x) for x in items]
    vectors = model.encode(queries, convert_to_numpy=True, show_progress_bar=False)
    vectors = normalize(vectors)

    if len(items) == 1:
        labels = np.array([0])
        centers = np.array([vectors[0]])
        best_k, sil_scores = 1, {}
    else:
        best_k, sil_scores = choose_best_k(vectors, random_state)
        if best_k == 1:
            labels = np.zeros(len(items), dtype=int)
            centers = np.array([vectors.mean(axis=0)])
        else:
            km = KMeans(n_clusters=best_k, random_state=random_state, n_init="auto")
            labels = km.fit_predict(vectors)
            centers = km.cluster_centers_

    names = nearest_taxonomy_labels(centers, taxonomy_labels, taxonomy_vectors)
    cluster_infos = []
    for cid in range(best_k):
        c_items = [items[i] for i in range(len(items)) if labels[i] == cid]
        if not c_items:
            continue
        label, score = names[cid]
        cluster_infos.append({"id": cid, "label": label, "taxonomy_score": score, "items": c_items})

    ranked = priority_order(cluster_infos)
    priority_by_id = {c["id"]: i + 1 for i, c in enumerate(ranked)}

    print(f"[LAYER] {parent} | items={len(items)} | best_k={best_k}")

    op = {
        "type": "priority_cluster_move",
        "time": now_str(),
        "parent": rel(parent, root),
        "best_k": int(best_k),
        "silhouette_scores": {str(k): float(v) for k, v in sil_scores.items()},
        "moves": [],
    }

    for c in cluster_infos:
        priority = priority_by_id[c["id"]]
        cluster_num = c["id"] + 1
        folder_name = f"P{priority:02d}_{cluster_num:02d}_{safe_name(c['label'])}"
        dst_folder = parent / folder_name

        print(f"  [P{priority:02d}] {c['label']} | n={len(c['items'])} | score={c['taxonomy_score']:.4f}")

        if not dry_run:
            dst_folder.mkdir(parents=True, exist_ok=True)

        for item in c["items"]:
            dst = unique_path(dst_folder / item.name)
            if dry_run:
                print(f"    WOULD MOVE: {item.name} -> {folder_name}/")
                continue

            try:
                src_rel = rel(item, root)
                shutil.move(str(item), str(dst))
                dst_rel = rel(dst, root)
                op["moves"].append({
                    "source_path": src_rel,
                    "dest_path": dst_rel,
                    "item_type": "folder" if dst.is_dir() else "file",
                    "priority": priority,
                    "cluster_id": cluster_num,
                    "taxonomy_label": c["label"],
                    "taxonomy_score": float(c["taxonomy_score"]),
                })
                print(f"    MOVED: {item.name} -> {folder_name}/")
            except (PermissionError, FileNotFoundError, OSError) as e:
                print(f"    SKIP: {item.name} | {e}")

    if op["moves"]:
        manifest["operations"].append(op)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--paths", default=None, help="TXT file with file/folder paths from UI")
    ap.add_argument("--old", default=None, help="Single root folder path")
    ap.add_argument("--taxonomy", default="clean_taxonomy.txt")
    ap.add_argument("--model", default="sentence-transformers/all-MiniLM-L6-v2")
    ap.add_argument("--archive-months", type=int, default=6)
    ap.add_argument("--no-archive", action="store_true")
    ap.add_argument("--archive-remove-original", action="store_true")
    ap.add_argument("--allow-folder-move", action="store_true", help="Allow moving folders as layer items. Default: only files.")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--random-state", type=int, default=42)
    args = ap.parse_args()

    paths = read_input_paths(args.paths, args.old)
    if not paths:
        raise ValueError("No valid paths. Use --paths selected_paths.txt or --old folder.")

    taxonomy_path = Path(args.taxonomy).expanduser()
    if not taxonomy_path.is_absolute():
        taxonomy_path = Path.cwd() / taxonomy_path
    taxonomy_labels = load_taxonomy(taxonomy_path.resolve())

    roots = roots_from_paths(paths)
    print(f"[ROOTS] {len(roots)} root(s)")
    print(f"[RULE] Same parent layer only. Protected code files untouched.")
    print(f"[RULE] Folder moves allowed: {args.allow_folder_move}")
    print(f"[RULE] Dry run: {args.dry_run}")
    print()

    print(f"[LOAD] model: {args.model}")
    model = SentenceTransformer(args.model)

    print("[EMBED] taxonomy")
    tax_text = [x.replace("/", " ") for x in taxonomy_labels]
    taxonomy_vectors = normalize(model.encode(tax_text, convert_to_numpy=True, show_progress_bar=True))

    for root in roots:
        manifest = {
            "tool": "rearrange_deep.py",
            "version": "1.0",
            "root": str(root.resolve()),
            "created_at": now_str(),
            "rules": {
                "same_layer_only": True,
                "protected_code_files_untouched": True,
                "ignore_duplicate_names_in_same_layer": True,
                "allow_folder_move": bool(args.allow_folder_move),
                "archive_months": args.archive_months,
                "archive_remove_original": bool(args.archive_remove_original),
            },
            "input_paths": [str(p) for p in paths],
            "operations": [],
        }

        print(f"\n[PROCESS ROOT] {root}")
        by_parent = selected_items_by_parent(paths, root, args.allow_folder_move)

        parents = sorted(by_parent.keys(), key=lambda p: len(p.relative_to(root).parts), reverse=True)
        for parent in parents:
            # refresh only existing direct items
            items = [x for x in by_parent[parent] if x.exists() and x.parent == parent and safe_to_touch(x, args.allow_folder_move)]
            if not items:
                continue

            if not args.no_archive:
                items = archive_old_items(parent, root, items, args.archive_months, args.archive_remove_original, args.dry_run, manifest)

            cluster_and_move(parent, root, items, model, taxonomy_labels, taxonomy_vectors, args.random_state, args.dry_run, manifest)

        if not args.dry_run:
            manifest_path = root / "_rearrange_deep_manifest.json"
            report_path = root / "_rearrange_deep_report.txt"
            manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
            report_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
            print(f"[MANIFEST] {manifest_path}")

    print("\nOK")


if __name__ == "__main__":
    main()
