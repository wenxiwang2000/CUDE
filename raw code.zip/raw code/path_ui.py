# drag_path_copy_ui.py
# Drag files/folders into this UI and collect only their paths.
# It does NOT copy or modify anything.
#
# Install:
#   pip install tkinterdnd2
#
# Run:
#   python drag_path_copy_ui.py
#
# Output:
#   selected_paths.txt

from pathlib import Path
import tkinter as tk
from tkinter import messagebox, filedialog

try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
except ImportError:
    raise SystemExit("Missing tkinterdnd2. Install with: pip install tkinterdnd2")


def parse_drop_paths(raw: str):
    return root.tk.splitlist(raw)


def norm_path(p: str) -> str:
    return str(Path(p).expanduser().resolve())


def existing_items():
    return {listbox.get(i) for i in range(listbox.size())}


def add_path(p: str):
    path = Path(p).expanduser().resolve()
    if not path.exists():
        listbox.insert(tk.END, f"SKIP missing: {path}")
        return

    s = str(path)
    if s not in existing_items():
        listbox.insert(tk.END, s)


def on_drop(event):
    for p in parse_drop_paths(event.data):
        add_path(p)


def add_file_dialog():
    paths = filedialog.askopenfilenames(title="Choose files")
    for p in paths:
        add_path(p)


def add_folder_dialog():
    folder = filedialog.askdirectory(title="Choose folder")
    if folder:
        add_path(folder)


def remove_selected():
    for i in reversed(list(listbox.curselection())):
        listbox.delete(i)


def clear_all():
    listbox.delete(0, tk.END)


def valid_paths():
    out = []
    seen = set()
    for i in range(listbox.size()):
        item = listbox.get(i)
        if item.startswith("SKIP"):
            continue
        p = Path(item)
        if p.exists():
            s = str(p.resolve())
            if s not in seen:
                seen.add(s)
                out.append(s)
    return out


def copy_paths():
    paths = valid_paths()
    root.clipboard_clear()
    root.clipboard_append("\n".join(paths))
    messagebox.showinfo("Copied", f"Copied {len(paths)} path(s).")


def save_paths():
    paths = valid_paths()
    if not paths:
        messagebox.showinfo("No paths", "No valid paths to save.")
        return
    out = Path(__file__).with_name("selected_paths.txt")
    out.write_text("\n".join(paths) + "\n", encoding="utf-8")
    messagebox.showinfo("Saved", f"Saved {len(paths)} path(s) to:\n{out}")


root = TkinterDnD.Tk()
root.title("Drag File/Folder Paths")
root.geometry("850x520")

tk.Label(root, text="Drag files or folders here", font=("Arial", 16, "bold")).pack(pady=(12, 4))
tk.Label(root, text="Only paths are collected. Nothing is copied or modified.").pack(pady=(0, 8))

listbox = tk.Listbox(root, width=120, height=20, selectmode=tk.EXTENDED)
listbox.pack(padx=12, pady=8, fill="both", expand=True)
listbox.drop_target_register(DND_FILES)
listbox.dnd_bind("<<Drop>>", on_drop)

btns = tk.Frame(root)
btns.pack(pady=10)

tk.Button(btns, text="Add file", command=add_file_dialog, width=12).grid(row=0, column=0, padx=5)
tk.Button(btns, text="Add folder", command=add_folder_dialog, width=12).grid(row=0, column=1, padx=5)
tk.Button(btns, text="Remove selected", command=remove_selected, width=16).grid(row=0, column=2, padx=5)
tk.Button(btns, text="Clear", command=clear_all, width=10).grid(row=0, column=3, padx=5)
tk.Button(btns, text="Copy paths", command=copy_paths, width=12).grid(row=0, column=4, padx=5)
tk.Button(btns, text="Save paths", command=save_paths, width=12).grid(row=0, column=5, padx=5)

root.mainloop()
