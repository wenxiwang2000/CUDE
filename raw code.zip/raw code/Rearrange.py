# Rearrange.py
# Deep folder rearranger with JSON undo manifest.
#
# Main idea:
# - Process deepest folders first, then root.
# - Only touch safe non-code files.
# - Never move/zip/delete protected code files.
# - Never move folders as whole units.
# - Every move/archive/remove action is recorded in _rearrange_manifest.json.
# - Use Derearrange.py with the manifest to restore moved files.
#
# Install:
#   pip install sentence-transformers scikit-learn numpy
#
# Put together:
#   Rearrange.py
#   Derearrange.py
#   clean_taxonomy.txt
#
# Preview:
#   python Rearrange.py --old "C:\path\to\folder" --dry-run
#
# Run:
#   python Rearrange.py --old "C:\path\to\folder"
#
# Only touch selected safe file types:
#   python Rearrange.py --old "C:\path\to\folder" --safe-exts ".txt,.png,.jpg,.pdf"
#
# Restore:
#   python Derearrange.py --manifest "C:\path\to\folder\_rearrange_manifest.json"

import argparse
import json
import shutil
import zipfile
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import normalize


PROTECTED_EXTS = {
    ".py", ".pyw", ".ipynb",
    ".bat", ".cmd", ".ps1", ".sh", ".bash", ".zsh",
    ".js", ".jsx", ".ts", ".tsx",
    ".html", ".htm", ".css", ".scss",
    ".json", ".yaml", ".yml", ".xml", ".toml", ".ini", ".cfg", ".conf",
    ".sql", ".r", ".rmd",
    ".java", ".c", ".cpp", ".h", ".hpp", ".cs", ".go", ".rs", ".swift", ".kt",
    ".php", ".rb", ".pl", ".lua",
    ".exe", ".dll", ".sys", ".msi", ".app", ".dmg",
    ".lnk", ".url",
}

DEFAULT_SAFE_EXTS = set()


def now_str() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def safe_name(name: str) -> str:
    bad = '<>:"/\\|?*'
    for ch in bad:
        name = name.replace(ch, "_")
    name = name.replace("/", "__")
    return name.strip() or "cluster"


def unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    parent = path.parent
    stem = path.stem
    suffix = path.suffix
    i = 2
    while True:
        new_path = parent / f"{stem}_{i}{suffix}"
        if not new_path.exists():
            return new_path
        i += 1


def rel(path: Path, root: Path) -> str:
    return str(path.resolve().relative_to(root.resolve())).replace("\\", "/")


def is_cluster_folder(path: Path) -> bool:
    return path.is_dir() and len(path.name) >= 3 and path.name[:2].isdigit() and path.name[2] == "_"


def is_system_output(path: Path) -> bool:
    name = path.name
    if name in {"_rearrange_report.txt", "_rearrange_manifest.json"}:
        return True
    if name.startswith("_archive_not_modified_") and path.suffix.lower() == ".zip":
        return True
    return False


def parse_safe_exts(s: str | None) -> set[str]:
    if not s:
        return DEFAULT_SAFE_EXTS
    out = set()
    for x in s.split(","):
        x = x.strip().lower()
        if not x:
            continue
        if not x.startswith("."):
            x = "." + x
        out.add(x)
    return out


def is_safe_file(path: Path, safe_exts: set[str]) -> bool:
    if not path.is_file():
        return False
    if is_system_output(path):
        return False
    ext = path.suffix.lower()
    if ext in PROTECTED_EXTS:
        return False
    if safe_exts and ext not in safe_exts:
        return False
    return True


def load_taxonomy(path: Path) -> list[str]:
    if not path.exists():
        raise FileNotFoundError(f"Taxonomy file not found: {path}")

    labels = []
    seen = set()
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "/" not in line:
            continue
        if line not in seen:
            seen.add(line)
            labels.append(line)

    if not labels:
        raise ValueError("No valid taxonomy labels found. Use parent/child format, one per line.")
    return labels


def item_text(path: Path) -> str:
    return path.stem.replace("_", " ").replace("-", " ")


def k_range_by_size(n: int) -> list[int]:
    if n < 3:
        return []
    if n < 50:
        hi = 6
    elif n <= 300:
        hi = 12
    else:
        hi = 20
    hi = min(hi, n - 1)
    return list(range(2, hi + 1))


def choose_best_k(vectors: np.ndarray, random_state: int = 42) -> tuple[int, dict[int, float]]:
    n = len(vectors)
    ks = k_range_by_size(n)
    if not ks:
        return 1, {}

    scores = {}
    best_k = ks[0]
    best_score = -999.0

    for k in ks:
        km = KMeans(n_clusters=k, random_state=random_state, n_init="auto")
        labels = km.fit_predict(vectors)

        if len(set(labels)) < 2 or len(set(labels)) >= n:
            continue

        score = silhouette_score(vectors, labels, metric="cosine")
        scores[k] = float(score)

        if score > best_score:
            best_score = score
            best_k = k

    return best_k, scores


def nearest_taxonomy_labels(centers: np.ndarray, taxonomy_labels: list[str], taxonomy_vectors: np.ndarray) -> list[tuple[str, float]]:
    centers = normalize(centers)
    taxonomy_vectors = normalize(taxonomy_vectors)

    results = []
    used = set()

    for center in centers:
        sims = taxonomy_vectors @ center
        order = np.argsort(-sims)

        chosen_idx = int(order[0])
        for idx in order:
            label = taxonomy_labels[int(idx)]
            if label not in used:
                chosen_idx = int(idx)
                break

        label = taxonomy_labels[chosen_idx]
        score = float(sims[chosen_idx])
        used.add(label)
        results.append((label, score))

    return results


def cluster_folder_name(label: str, cluster_id: int) -> str:
    return f"{cluster_id:02d}_{safe_name(label)}"


def add_file_to_zip(zipf: zipfile.ZipFile, file_path: Path, root: Path) -> str:
    arcname = rel(file_path, root)
    zipf.write(file_path, arcname)
    return arcname


def archive_old_safe_files(folder: Path, root: Path, files: list[Path], months: int, dry_run: bool,
                           remove_original: bool, manifest: dict, report: list[str]) -> list[Path]:
    cutoff = datetime.now() - timedelta(days=months * 30)
    cutoff_ts = cutoff.timestamp()

    old_files = []
    keep_files = []

    for f in files:
        try:
            mt = f.stat().st_mtime
        except (FileNotFoundError, PermissionError):
            keep_files.append(f)
            continue

        if mt < cutoff_ts:
            old_files.append(f)
        else:
            keep_files.append(f)

    if not old_files:
        return keep_files

    zip_path = unique_path(folder / f"_archive_not_modified_{months}_months.zip")
    print(f"[ARCHIVE] {folder} -> {zip_path.name} | {len(old_files)} old safe file(s)")
    report.append(f"ARCHIVE folder={folder}")
    report.append(f"zip={zip_path}")

    archive_record = {
        "type": "archive_zip",
        "time": now_str(),
        "zip_path": rel(zip_path, root),
        "folder": rel(folder, root),
        "months": months,
        "remove_original": bool(remove_original),
        "files": [],
    }

    for f in old_files:
        dt = datetime.fromtimestamp(f.stat().st_mtime).strftime("%Y-%m-%d %H:%M")
        print(f"  OLD SAFE FILE: {f.name} | last_modified={dt}")
        report.append(f"- archive_safe_file: {f} | last_modified={dt}")
        archive_record["files"].append({
            "original_path": rel(f, root),
            "last_modified": dt,
            "arcname": rel(f, root),
        })

    if dry_run:
        report.append("dry_run=true, zip not created")
        report.append("")
        return keep_files

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zipf:
        for f in old_files:
            try:
                arcname = add_file_to_zip(zipf, f, root)
                for rec in archive_record["files"]:
                    if rec["original_path"] == rel(f, root):
                        rec["arcname"] = arcname
            except (FileNotFoundError, PermissionError):
                pass

    if remove_original:
        removed_paths = []
        for f in old_files:
            try:
                f.unlink()
                removed_paths.append(rel(f, root))
                report.append(f"- removed_original_after_zip: {f}")
            except (FileNotFoundError, PermissionError):
                pass
        archive_record["removed_original_paths"] = removed_paths
    else:
        report.append("original_old_safe_files_kept=true")

    manifest["operations"].append(archive_record)
    report.append("")
    return keep_files


def direct_safe_files(folder: Path, safe_exts: set[str]) -> list[Path]:
    files = []
    try:
        for x in folder.iterdir():
            if is_system_output(x):
                continue
            if is_cluster_folder(x):
                continue
            if is_safe_file(x, safe_exts):
                files.append(x)
    except PermissionError:
        pass
    return files


def all_folders_deepest_first(root: Path) -> list[Path]:
    folders = []
    for p in root.rglob("*"):
        if p.is_dir():
            if is_cluster_folder(p):
                continue
            folders.append(p)

    folders.append(root)
    folders = list(dict.fromkeys(folders))
    folders.sort(key=lambda p: len(p.relative_to(root).parts), reverse=True)
    return folders


def move_file(src: Path, dst: Path) -> Path:
    dst = unique_path(dst)
    shutil.move(str(src), str(dst))
    return dst


def cluster_folder_files(folder: Path, root: Path, files: list[Path], model: SentenceTransformer,
                         taxonomy_labels: list[str], taxonomy_vectors: np.ndarray,
                         random_state: int, dry_run: bool, manifest: dict, report: list[str]) -> None:
    if not files:
        return

    queries = [item_text(f) for f in files]
    vectors = model.encode(queries, convert_to_numpy=True, show_progress_bar=False)
    vectors = normalize(vectors)

    if len(files) == 1:
        labels = np.array([0])
        centers = np.array([vectors[0]])
        best_k = 1
        sil_scores = {}
    else:
        best_k, sil_scores = choose_best_k(vectors, random_state=random_state)
        if best_k == 1:
            labels = np.zeros(len(files), dtype=int)
            centers = np.array([vectors.mean(axis=0)])
        else:
            km = KMeans(n_clusters=best_k, random_state=random_state, n_init="auto")
            labels = km.fit_predict(vectors)
            centers = km.cluster_centers_

    cluster_names = nearest_taxonomy_labels(centers, taxonomy_labels, taxonomy_vectors)

    print(f"[CLUSTER] {folder} | safe_files={len(files)} | best_k={best_k}")
    report.append(f"CLUSTER folder={folder}")
    report.append(f"safe_files={len(files)}")
    report.append(f"best_k={best_k}")

    cluster_record = {
        "type": "cluster_move",
        "time": now_str(),
        "folder": rel(folder, root),
        "best_k": int(best_k),
        "silhouette_scores": {str(k): float(v) for k, v in sil_scores.items()},
        "moves": [],
    }

    for cluster_id in range(best_k):
        tax_label, tax_score = cluster_names[cluster_id]
        cluster_files = [files[i] for i in range(len(files)) if labels[i] == cluster_id]
        if not cluster_files:
            continue

        folder_name = cluster_folder_name(tax_label, cluster_id + 1)
        dst_folder = folder / folder_name

        print(f"  -> {folder_name} | taxonomy_score={tax_score:.4f} | n={len(cluster_files)}")
        report.append(f"cluster_{cluster_id + 1}={tax_label}, score={tax_score:.6f}, n={len(cluster_files)}")

        if not dry_run:
            dst_folder.mkdir(parents=True, exist_ok=True)

        for f in cluster_files:
            dst = dst_folder / f.name
            if dry_run:
                print(f"     WOULD MOVE file: {f.name}")
                report.append(f"- WOULD MOVE safe_file: {f} -> {dst_folder}")
            else:
                try:
                    src_rel = rel(f, root)
                    final_dst = move_file(f, dst)
                    dst_rel = rel(final_dst, root)
                    print(f"     MOVED file: {f.name} -> {final_dst.parent.name}/")
                    report.append(f"- MOVED safe_file: {src_rel} -> {dst_rel}")
                    cluster_record["moves"].append({
                        "source_path": src_rel,
                        "dest_path": dst_rel,
                        "taxonomy_label": tax_label,
                        "taxonomy_score": float(tax_score),
                    })
                except (FileNotFoundError, PermissionError) as e:
                    print(f"     SKIP file: {f.name} | {e}")
                    report.append(f"- SKIP safe_file: {f} | {e}")

    if cluster_record["moves"]:
        manifest["operations"].append(cluster_record)

    report.append("")


def main() -> None:
    parser = argparse.ArgumentParser(description="Deep rearrange safe files and write JSON undo manifest.")
    parser.add_argument("--old", required=True, help="Root folder to deep rearrange")
    parser.add_argument("--taxonomy", default="clean_taxonomy.txt", help="Taxonomy txt path")
    parser.add_argument("--model", default="sentence-transformers/all-MiniLM-L6-v2", help="Embedding model")
    parser.add_argument("--archive-months", type=int, default=6, help="Zip safe files not modified for this many months")
    parser.add_argument("--no-archive", action="store_true", help="Disable zip archive step")
    parser.add_argument("--archive-remove-original", action="store_true", help="After zipping old safe files, delete originals")
    parser.add_argument("--safe-exts", default=None, help='Optional allowed safe extensions, e.g. ".txt,.png,.jpg,.pdf"')
    parser.add_argument("--dry-run", action="store_true", help="Preview only; no zip, no move, no manifest write")
    parser.add_argument("--random-state", type=int, default=42)
    args = parser.parse_args()

    root = Path(args.old).expanduser().resolve()
    if not root.exists() or not root.is_dir():
        raise FileNotFoundError(f"Root folder not found: {root}")

    taxonomy_path = Path(args.taxonomy).expanduser()
    if not taxonomy_path.is_absolute():
        taxonomy_path = Path.cwd() / taxonomy_path
    taxonomy_path = taxonomy_path.resolve()

    safe_exts = parse_safe_exts(args.safe_exts)

    manifest = {
        "tool": "Rearrange.py",
        "version": "2.0-json-undo",
        "root": str(root),
        "created_at": now_str(),
        "dry_run": bool(args.dry_run),
        "rules": {
            "deepest_first": True,
            "protected_code_files_untouched": True,
            "folders_not_moved_as_whole_units": True,
            "safe_exts": sorted(safe_exts) if safe_exts else "all_non_protected",
            "archive_months": args.archive_months,
            "archive_remove_original": bool(args.archive_remove_original),
        },
        "operations": [],
    }

    print("[RULE]")
    print("  Deep mode: process deepest folders first, then root.")
    print("  Protected code files are never moved/zipped/deleted.")
    print("  Folders are never moved as whole units.")
    print("  Only safe non-code files are rearranged.")
    print("  JSON undo manifest will be saved as _rearrange_manifest.json.")
    if safe_exts:
        print(f"  Safe extensions restricted to: {', '.join(sorted(safe_exts))}")
    else:
        print("  Safe extensions: all non-protected files.")
    print()

    print(f"[LOAD] taxonomy: {taxonomy_path}")
    taxonomy_labels = load_taxonomy(taxonomy_path)
    print(f"[TAXONOMY] {len(taxonomy_labels)} labels")

    print(f"[LOAD] embedding model: {args.model}")
    model = SentenceTransformer(args.model)

    print("[EMBED] taxonomy labels")
    tax_text = [x.replace("/", " ") for x in taxonomy_labels]
    taxonomy_vectors = model.encode(tax_text, convert_to_numpy=True, show_progress_bar=True)
    taxonomy_vectors = normalize(taxonomy_vectors)

    report = []
    report.append("# Rearrange.py deep-clean report")
    report.append(f"root={root}")
    report.append(f"started={now_str()}")
    report.append("rule=protected code files are never moved/zipped/deleted")
    report.append("rule=folders are not moved as whole units")
    report.append("")

    folders = all_folders_deepest_first(root)
    print(f"[FOLDERS] {len(folders)} folder(s), deepest first")
    print()

    total_safe_files_seen = 0

    for folder in folders:
        if not folder.exists() or not folder.is_dir():
            continue

        files = direct_safe_files(folder, safe_exts)
        if not files:
            continue

        total_safe_files_seen += len(files)

        if not args.no_archive:
            files = archive_old_safe_files(
                folder=folder,
                root=root,
                files=files,
                months=args.archive_months,
                dry_run=args.dry_run,
                remove_original=args.archive_remove_original,
                manifest=manifest,
                report=report,
            )

        cluster_folder_files(
            folder=folder,
            root=root,
            files=files,
            model=model,
            taxonomy_labels=taxonomy_labels,
            taxonomy_vectors=taxonomy_vectors,
            random_state=args.random_state,
            dry_run=args.dry_run,
            manifest=manifest,
            report=report,
        )

    report.append(f"total_safe_files_seen={total_safe_files_seen}")
    report.append(f"finished={now_str()}")

    report_path = root / "_rearrange_report.txt"
    manifest_path = root / "_rearrange_manifest.json"

    if not args.dry_run:
        report_path.write_text("\n".join(report), encoding="utf-8")
        manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")

    print()
    print("OK")
    if args.dry_run:
        print("Dry run complete. Nothing was zipped or moved.")
    else:
        print(f"Deep rearranged in place: {root}")
        print(f"Report: {report_path}")
        print(f"Manifest: {manifest_path}")


if __name__ == "__main__":
    main()
