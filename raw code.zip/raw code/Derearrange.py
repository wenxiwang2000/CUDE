# Derearrange.py
# Undo tool for Rearrange.py.
#
# It reads _rearrange_manifest.json and moves files back from arranged paths
# to their original paths.
#
# It can also restore files that were archived and removed, if the ZIP still exists.
#
# Preview:
#   python Derearrange.py --manifest "C:\path\to\folder\_rearrange_manifest.json" --dry-run
#
# Restore:
#   python Derearrange.py --manifest "C:\path\to\folder\_rearrange_manifest.json"
#
# Notes:
# - It does not delete cluster folders by default.
# - Use --remove-empty-folders to remove empty folders after restoring.

import argparse
import json
import shutil
import zipfile
from pathlib import Path


def unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    parent = path.parent
    stem = path.stem
    suffix = path.suffix
    i = 2
    while True:
        new_path = parent / f"{stem}_restored_{i}{suffix}"
        if not new_path.exists():
            return new_path
        i += 1


def abs_from_root(root: Path, rel_path: str) -> Path:
    return root / rel_path.replace("/", "\\")


def move_back(src: Path, dst: Path, dry_run: bool) -> None:
    dst = unique_path(dst)
    if dry_run:
        print(f"WOULD MOVE BACK: {src} -> {dst}")
        return
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(src), str(dst))
    print(f"MOVED BACK: {src} -> {dst}")


def restore_archived_removed_files(root: Path, op: dict, dry_run: bool) -> None:
    zip_path = abs_from_root(root, op["zip_path"])
    if not zip_path.exists():
        print(f"SKIP archive restore, zip not found: {zip_path}")
        return

    removed = set(op.get("removed_original_paths", []))
    if not removed:
        return

    print(f"[RESTORE ZIP] {zip_path.name}")

    with zipfile.ZipFile(zip_path, "r") as zipf:
        names = set(zipf.namelist())
        for f in op.get("files", []):
            original_rel = f["original_path"]
            arcname = f.get("arcname", original_rel)
            if original_rel not in removed:
                continue
            if arcname not in names:
                print(f"  SKIP missing in zip: {arcname}")
                continue

            dst = abs_from_root(root, original_rel)
            if dst.exists():
                print(f"  SKIP already exists: {dst}")
                continue

            if dry_run:
                print(f"  WOULD EXTRACT: {arcname} -> {dst}")
            else:
                dst.parent.mkdir(parents=True, exist_ok=True)
                zipf.extract(arcname, root)
                print(f"  EXTRACTED: {arcname} -> {dst}")


def remove_empty_folders(root: Path, dry_run: bool) -> None:
    folders = [p for p in root.rglob("*") if p.is_dir()]
    folders.sort(key=lambda p: len(p.relative_to(root).parts), reverse=True)

    for folder in folders:
        try:
            if any(folder.iterdir()):
                continue
        except PermissionError:
            continue

        if dry_run:
            print(f"WOULD REMOVE EMPTY FOLDER: {folder}")
        else:
            try:
                folder.rmdir()
                print(f"REMOVED EMPTY FOLDER: {folder}")
            except OSError:
                pass


def main() -> None:
    parser = argparse.ArgumentParser(description="Undo Rearrange.py using _rearrange_manifest.json.")
    parser.add_argument("--manifest", required=True, help="Path to _rearrange_manifest.json")
    parser.add_argument("--dry-run", action="store_true", help="Preview only")
    parser.add_argument("--remove-empty-folders", action="store_true", help="Remove empty folders after restoring")
    args = parser.parse_args()

    manifest_path = Path(args.manifest).expanduser().resolve()
    if not manifest_path.exists():
        raise FileNotFoundError(f"Manifest not found: {manifest_path}")

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    root = Path(manifest["root"]).expanduser().resolve()

    if not root.exists():
        raise FileNotFoundError(f"Root folder from manifest not found: {root}")

    print(f"[ROOT] {root}")
    print(f"[MANIFEST] {manifest_path}")
    print(f"[MODE] {'DRY RUN' if args.dry_run else 'RESTORE'}")
    print()

    # Reverse move operations in reverse order.
    operations = manifest.get("operations", [])

    print("[STEP 1] Restore moved files")
    for op in reversed(operations):
        if op.get("type") != "cluster_move":
            continue
        for mv in reversed(op.get("moves", [])):
            src = abs_from_root(root, mv["dest_path"])
            dst = abs_from_root(root, mv["source_path"])
            if not src.exists():
                print(f"SKIP missing moved file: {src}")
                continue
            if dst.exists():
                dst = unique_path(dst)
            move_back(src, dst, args.dry_run)

    print()
    print("[STEP 2] Restore archived removed files, if any")
    for op in reversed(operations):
        if op.get("type") == "archive_zip":
            restore_archived_removed_files(root, op, args.dry_run)

    if args.remove_empty_folders:
        print()
        print("[STEP 3] Remove empty folders")
        remove_empty_folders(root, args.dry_run)

    print()
    print("OK")
    if args.dry_run:
        print("Dry run complete. Nothing was moved.")
    else:
        print("Derearrange complete.")


if __name__ == "__main__":
    main()
